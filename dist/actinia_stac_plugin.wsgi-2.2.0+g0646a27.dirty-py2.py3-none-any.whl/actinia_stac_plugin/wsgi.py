from actinia_stac_plugin.main import app as application
